Para correr, realizar o seguinte comando:

TuringMachine [nome de ficheiro de c�digo]

Qualquer ficheiro de c�digo dever� ter o formato especificado e demonstrado no ficheiro de exemplo.